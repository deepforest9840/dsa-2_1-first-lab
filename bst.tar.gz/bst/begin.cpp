#include<iostream>
#include<queue>
#include <climits>
using namespace std;
#define int int
struct node{
	int data;
	struct node* left;
	struct node* right;
	
};
struct node* get_new_node(int data){
	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=data;
	newnode->left=newnode->right=NULL;
	return newnode;
}
struct node* insert(struct node* root,int data){
	if(root==NULL){
		root=get_new_node(data);
	}
	else if(data<=root->data){
		root->left=insert(root->left,data);
	}
	else {
		root->right=insert(root->right,data);
	}
	return root;
}
struct node* find_min(struct node* root){
 if(root->left==NULL){
	return root;
}
return find_min(root->left);
}
int find_max(struct node* root){
	if(root==NULL){
		cout<<"tree is empty";
		return -1;
	}
	else if(root->right==NULL) {return root->data;}
	return find_max(root->right);
}
int find_height(struct node* root){
	if(root==NULL) {return -1;}
	return max(find_height(root->left),find_height(root->right))+1;
}

void level_order(struct node* root){
	if(root==NULL) {cout<<" tree is emtpy"; return;}
	queue<struct node*>q;
	q.push(root);
	while(!q.empty()){
		struct node* cur=q.front();
		cout<<cur->data<<" ";
		if(cur->left!=NULL) q.push(cur->left);
		if(cur->right!=NULL) q.push(cur->right);
		q.pop();
	}
	
	
}
void pre_order(struct node* root){
	if(root==NULL) return ;
	cout<<root->data<<" ";
	pre_order(root->left);
	pre_order(root->right);
}

void in_order(struct node* root){
	if(root==NULL) return ;
	in_order(root->left);
	cout<<root->data<<" ";
	in_order(root->right);
}
void post_order(struct node* root){
	if(root==NULL) return ;
	post_order(root->left);
	post_order(root->right);
	cout<<root->data<<" ";
}
bool is_bst_util(struct node* root,int minv,int maxv){
	if(root==NULL) return true;
	if(root->data>minv && root->data<maxv && is_bst_util(root->left,minv,root->data)&&is_bst_util(root->right,root->data,maxv) )
	return true;
	else return false;
}
bool is_bst(struct node* root){
	return is_bst_util(root,INT_MIN,INT_MAX);
}
struct node* Delete(struct node* root,int data){
	if(root==NULL) return root;
	else if(data<root->data	) root->left=Delete(root->left,data);
	else if(data>root->data) root->right=Delete(root->right,data);
	else{
		if(root->left==NULL && root->right==NULL){
			delete root;
			root=NULL;
		}
		else if(root->left==NULL){
			struct node* temp=root;
			root=root->right;
			delete temp;
		}
		else if(root->right==NULL){
			struct node* temp=root;
			root=root->left;
			delete temp;
		}
		else {
			struct node* temp=find_min(root->right);
			root->data=temp->data;
			root->right=Delete(root->right,temp->data);
		}
	}
	return root;
}
int main(){
	struct node* root=NULL;
	root=insert(root,15);
	root=insert(root,10);
	root=insert(root,20);
	root=insert(root,25);
	root=insert(root,8);
	root=insert(root,12);root=insert(root,14);root=insert(root,11);root=insert(root,4);
	//cout<<find_min(root)<<endl;
	cout<<find_max(root)<<endl;
	cout<<find_height(root)<<endl;
	//level_order(root);
	
	cout<<endl;
	//
	//level_order(root);
	pre_order(root);
	cout<<endl;
	//in_order(root);
	//cout<<is_bst(root);
	root=Delete(root,10);
	cout<<endl;
	pre_order(root);
	
	
	
}









