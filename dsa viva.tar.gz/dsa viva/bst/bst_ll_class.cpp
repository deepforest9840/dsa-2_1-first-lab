#include<iostream>
#include<queue>
#include <climits>
using namespace std;
struct node{
	int data;
	string s;
	struct node* left;
	struct node* right;
	
};

struct node* out_get_new_node(struct node* root,int data,string s){
	struct node* newnode=(struct node*)malloc(sizeof(struct node));
	newnode->data=data;
	newnode->s=s;
	newnode->left=newnode->right=NULL;
	root=newnode;
	return root;
}
struct node* out_insert(struct node* root,int data,string s){
	if(root==NULL){
		root=out_get_new_node(root,data,s);
	}
	else if(data<=root->data){
		root->left=out_insert(root->left,data,s);
	}
	else if(data>root->data){
		root->right=out_insert(root->right,data,s);
	}
	return root;
}

void out_pre_order(struct node* root){
	if(root==NULL) return;
	cout<<"roll is : "<<root->data<<" and name is : "<<root->s<<endl;
	out_pre_order(root->left);
	out_pre_order(root->right);
}

void out_in_order(struct node* root){
	if(root==NULL) return;
	out_in_order(root->left);
	cout<<"roll is : "<<root->data<<" and name is : "<<root->s<<endl;
	out_in_order(root->right);
}
void out_post_order(struct node* root){
	if(root==NULL) return;
	out_post_order(root->left);
	out_post_order(root->right);
	cout<<"roll is : "<<root->data<<" and name is : "<<root->s<<endl;
}
struct node* find_min(struct node* root){
	if(root->left==NULL){
		return root;
	}
	return find_min(root->left);
}
struct node* out_delete(struct node* root,int data){
	if(root==NULL) return root;
	else if(data<root->data) {
		root->left=out_delete(root->left,data);
		
	}
	else if(data>root->data){
		root->right=out_delete(root->right,data);
	}
	else {
		if(root->left==NULL && root->right==NULL){
			//delete root;
			root=NULL;
		}
		else if(root->left==NULL){
			root=root->right;
		}
		else if(root->right==NULL){
			root=root->left;
		}
		else {
			struct node* temp=find_min(root->right);
			root->data=temp->data;
      			root->right=out_delete(root->right,temp->data);
			
		}
		
	
	}
	return root;
}

void out_level_order(struct node* root){
	if(root==NULL){
		cout<<"tree is empty"<<endl;
		return;
	}
	queue<struct node*>q;
	q.push(root);
	while(!q.empty()){
		struct node* cur=q.front();
		cout<<"roll is: "<<cur->data<<" and name is: "<<cur->s<<endl;
		if(cur->left!=NULL) q.push(cur->left);
		if(cur->right!=NULL) q.push(cur->right);
		q.pop();
	}
}
bool is_bst_util(struct node* root,int minv,int maxv){
	if(root==NULL) return true;
	if(root->data>minv&& root->data<maxv && is_bst_util(root->left,minv,root->data)&&is_bst_util(root->right,root->data,maxv))
	return true;
	else return false;
}
bool out_isbst(struct node* root){
	return is_bst_util(root,INT_MIN,INT_MAX);
}
int find_height(struct node* root){
	if(root==NULL) return -1;
	return max(find_height(root->left),find_height(root->right))+1;
	
}
bool isperfect_rect(struct node* root,int d,int level){
	if(root==NULL) return true;
	if(root->left==NULL&& root->right==NULL){
		return (d==level);
	
	}
	if(root->left==NULL||root->right==NULL){
		return false;
	}
	return isperfect_rect(root->left,d,level+1)&&isperfect_rect(root->right,d,level+1);
}
bool out_isperfect(struct node* root){
	int d=find_height(root);
	return isperfect_rect(root,d,0);
}


bool out_iscomplete(struct node* root){
	queue<struct node*>q;
	q.push(root);
	while(!q.empty()){
		struct node* cur=q.front();
		q.pop();
		if(cur!=NULL){
			q.push(cur->left);
			q.push(cur->right);
		}
		else{
			
			while(!q.empty()){
				if(q.front()){
					return false;
					
				}
				q.pop();
			}
		}
		
	}
	return true;
	
}


bool out_isfullb(struct node* root){
	if(root==NULL) return true;
	if(root->left==NULL&&root->right==NULL) return true;
	if((root->left)&&(root->right)){
		return (out_isfullb(root->left)&& out_isfullb(root->right));
	} 
	return false;
	
}
bool out_isbalance(struct node* root){
	if(root==NULL) return true;
	int lh=find_height(root->left);
	int rh=find_height(root->right);
	if(abs(lh-rh)<=1&& out_isbalance(root->left)&&out_isbalance(root->right)){
		return true;
	}
	return false;
}
bool out_left_skewed(struct node* root){
		if(root==NULL) return true;
		if(root->right!=NULL) return false;
		return out_left_skewed(root->left);
}
bool out_right_skewed(struct node* root){
		if(root==NULL) return true;
		if(root->left!=NULL) return false;
		return out_right_skewed(root->right);
}

struct bst{
	struct node*root=NULL;
	
	
	void  insert(int data,string s){
		root=out_insert(root,data,s);	
	}
	void show(){
		cout<<root->data<<" "<<root->right->data;//<<" "<<root->right->data<<endl;
	}
	void search(int data){
		if(root==NULL){
			cout<<"data is not found"<<endl;
			return;
		}
		struct node* p=root;
		while(p!=NULL){
			if(data==p->data){
				cout<<"data is found"<<endl;
				return;
			}
			else if(data<p->data){
				p=p->left;
			}
			else p=p->right;
		}
		if(p==NULL) cout<<"data is not found "<<endl;
		return;
	}
	void pre_order(){
		struct node* p=root;
		out_pre_order(p);
	}
	void in_order(){
		struct node* p=root;
		out_in_order(p);
	}
	void post_order(){
		struct node* p=root;
		out_post_order(p);
	}
	void Delete(int data){
		root=out_delete(root,data);
	}
	void level_order(){
		struct node* p=root;
		out_level_order(p);
	}
	
	void isbst(){
		struct node* p=root;
		if(out_isbst(p)) {cout<<"yes .It is a binary search tree "<<endl;}
		else{ cout<<" no.It is not a binary search tree"<<endl;
		}
	}
	void isperfect(){
	struct node* p=root;
		if(out_isperfect(p)) cout<<"yes ,it is a perfect binary tree because each leaf has same depth "<<endl;
		else cout<<"no,it is not a perfect binary tree "<<endl;
	}
	void iscomplete(){ 
		struct node* p=root;
		if(out_iscomplete(p)) cout<<"yes,this is a complete binary tree because its leftmost elements are full"<<endl;
		else cout<<"no,it is not a complete binary tree"<<endl;
	}
	void isfullb(){// isfullb=is full binary tree
		struct node* p=root;
		if(out_isfullb(p)) cout<<"yes ,this is a full binary tree because every node has either 2 node or no node"<<endl;
		else cout<<"no,this is not a full binary tree"<<endl;
	}
	void isbalance(){
		struct node* p=root;
		if(out_isbalance(p)) cout<<"yes , this is a balance binary tree because the difference of height of left subtree and right subtree is not more than 1"<<endl;
		else cout<<"no,this is not a balance binary tree"<<endl;
	}
	void isleft_skewed(){
		struct node* p=root;
		if(out_left_skewed(p)) cout<<"yes ,this is a left-skewed binary tree because every node is in left side "<<endl;
		else cout<<"no,this is not a left-skewed binary tree"<<endl;
	}
	void isright_skewed(){
		struct node* p=root;
		if(out_right_skewed(p)) cout<<"yes ,this is a right-skewed binary tree because every node is in right side "<<endl;
		else cout<<"no,this is not a right-skewed binary tree"<<endl;
	}
	
};


int main(){
	bst b;
	//fun("dfd");
	b.insert(15,"dsa");
	b.insert(10,"algo");
	b.insert(20,"eee");
	b.insert(25,"dle");
	b.insert(8,"java");
	b.insert(12,"sdl");
	b.insert(18,"la");
	b.insert(22,"ged");
	b.insert(27,"lab");
	b.Delete(20);
	//b.search(101);
	//b.pre_order();
	b.level_order();
	b.isbst();
	//b.isperfect();
	cout<<endl<<"second binary search tree"<<endl;
	bst bc;
	//fun("dfd");
	bc.insert(12,"dsa");
	bc.insert(5,"dsa");
	bc.insert(18,"dsa");
	//bc.insert(3,"dsa");
	//bc.insert(42,"ag");
//	bc.insert(51,"dsa");
//	bc.insert(63,"dsa");
	//bc.insert(20,"dsa");
	//bc.insert(25,"dsa");
	//bc.insert(115,"dsa");
	
	
	
	bc.level_order();
	bc.isperfect();
	bc.iscomplete();
	bc.isfullb();
	bc.isbalance();
	bc.isleft_skewed();
	bc.isright_skewed();
	bc.in_order();
	//b.show();
	cout<<endl<<"in order traversal"<<endl;
	b.in_order();
	cout<<endl<<"post order traversal"<<endl;
	b.post_order();
}



















