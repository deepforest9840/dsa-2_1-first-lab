#include<iostream>
#include<cstring>
#include<queue>
#include <climits>
#include<string>
using namespace std;
#define n 2240




bool out_bst_util(int ar[],int min,int max,int index){
	if(ar[index]==-1) return true;
	if((ar[index]>min) && (ar[index]<max)   
	&& (out_bst_util(ar,min,ar[index],index*2)&&
	out_bst_util(ar,ar[index],max,(index*2+1)))
	)  return true;
	else return false;
}

bool out_isbst(int ar[]){
	return out_bst_util(ar,INT_MIN,INT_MAX,1);
}
int find_height(int ar[],int index){
	if(ar[index]==-1) return -1;
	return max(find_height(ar,index*2),find_height(ar,(index*2+1)))+1;
}
bool isperfect_rect(int ar[],int d,int index,int level){
	if(ar[index]==-1) return true;
	if(ar[index*2]==-1 && ar[(index*2)+1]==-1) {
		return (d==level);
	}
	if(ar[index*2]==-1||ar[(index*2)+1]==-1){
		return false;
	}
	
	return (isperfect_rect(ar,d,index*2,level+1)&&isperfect_rect(ar,d,((index*2)+1),level+1));
}
bool out_isperfect(int ar[]){

		int d=find_height(ar,1);
		//cout<<endl<<"depth is : "<<d<<endl;
		return isperfect_rect(ar,d,1,0);
	
}




bool out_iscomplete(int ar[]){
	queue <int> q;
	//return true;
	q.push(ar[1]);
	int index=1;
	while(!q.empty()){
		int temp=q.front();
		q.pop();
		if(ar[index]!=-1){
			q.push(ar[index*2]);
			q.push(ar[(index*2)+1]);
		
		}
		else{
			
			while(!q.empty()){
				if(q.front()!=-1){
					return false;
				}
				q.pop();
			}
		
		}
		
			index++;
		
		
	}
	
	
	return true;

}
bool out_isfull(int ar[],int index=1){
		if(ar[index]==-1) return true;
		if(ar[index*2]==-1&& ar[index*2+1]==-1) return true;
		if(ar[index*2]!=-1&& ar[index*2+1]!=-1) {
			return (out_isfull(ar,index*2)&& out_isfull(ar,(index*2+1)));
		}
		return false;
}
bool out_isbalance(int ar[],int index=1){
	
	if(ar[index]==-1) return true;
	int lh=find_height(ar,index*2);
	int rh=find_height(ar,index*2+1);
	if(abs(lh-rh)<=1&& out_isbalance(ar,index*2)&& out_isbalance(ar,index*2+1)){
		return true;
	}
	
	return false;
	
}

bool out_is_left_skewed(int ar[],int index=1){
	if(ar[index]==-1) return true;
	if(ar[index*2+1]!=-1) return false;
	return out_is_left_skewed(ar,index*2);
}
bool out_is_right_skewed(int ar[],int index=1){
	if(ar[index]==-1) return true;
	if(ar[index*2]!=-1) return false;
	return out_is_right_skewed(ar,index*2+1);
}
struct bst{
	int* ar;
	int size=0;
	string* s;
	bst(){
		
		ar=new int[n];
		
		 s=new string[n];
		for(int i=0;i<n;i++){
			ar[i]=-1;
		}
		
	}
		
	void insert(int data,string s1,int index=1){
			if(index>n) {
				cout<<" no space is available "<<endl;
				return;
			}
			else{
				
				if(ar[index]==-1){
					ar[index]=data;
					s[index]=s1;
					size++;
					
					return;
				}
				else{
					
					if(data<ar[index]){
						insert(data,s1,index*2);
					}
					else{
						insert(data,s1,(index*2)+1);
					}
				}
			}
	}
	
	
	void show(){
		for(int i=1;i<n;i++){
			cout<<ar[i]<<endl;
		}
	}
	
	void preorder(int index=1){
		if(ar[index]!=-1){
			cout<<endl<<"index is "<<ar[index]<<" and name is: "<<s[index]<<endl;
			
			preorder(index*2);
			preorder(index*2+1);
		}
	}
	void inorder(int index=1){
	
		if(ar[index]!=-1){
			
			inorder(index*2);
			cout<<endl<<"index is "<<ar[index]<<" and name is: "<<s[index]<<endl;
			inorder(index*2+1);
		}
	}
	void postorder(int index=1){
		if(ar[index]!=-1){
		postorder(index*2);
			postorder(index*2+1);
			cout<<endl<<"index is "<<ar[index]<<" and name is: "<<s[index]<<endl;	
	}
	}
	void isbst(){
		
		if(out_isbst(ar)) {cout<<endl<<"yes .It is a binary search tree "<<endl;}
		else{ cout<<endl<<" no.It is not a binary search tree"<<endl;
		}
	}
	
	void isperfect(){
		if(out_isperfect(ar)) cout<<"yes,it is a perfect binary tree because each leaf has same depth "<<endl;
		else cout<<"no,this is not a perfect binary tree"<<endl;
	}
	
	void iscomplete(){
		if(out_iscomplete(ar)) cout<<"yes, this is a complete binary tree because its leftmost elements are full "<<endl;
		else cout<<"NO,it is not a complete binary tree"<<endl;
	
	}
	
	void isfull(){
		if(out_isfull(ar)) cout<<"yes,this is a full binary tree  because its every node has either two node or no node(child node) ."<<endl;
		else cout<<"no, this is not a full binary tree ."<<endl;
	}
	
	void isbalance(){
		if(out_isbalance(ar)) cout<<"yes , this is a balance binary tree because the height of left subtree and right subtree is not more than 1."<<endl;
		else cout<<"No,this is not  a balance binary tree "<<endl;
	}
	
	
	void is_left_skewed(){
		if(out_is_left_skewed(ar)) cout<<"yes,this is a left skewed tree because their is no node on the right side of any node."<<endl;
		else cout<<"No,this is not a left skewed tree "<<endl;
	}
	void is_right_skewed(){
		if(out_is_right_skewed(ar)) cout<<"yes,this is a left skewed tree because their is no node on the right side of any node."<<endl;
		else cout<<"No,this is not a left skewed tree "<<endl;
	}
	
	
};




int main(){
	bst b;
	b.insert(12,"dfdf");
//	b.insert(5);
	b.insert(18,"amdkfdioh");
	//b.insert();
	//b.insert(21);
	//b.insert(44);
	
	cout<<endl<<"traversing in pre order "<<endl;
	b.preorder();
	cout<<endl<<"traversing in post order "<<endl;
	b.postorder();
	cout<<endl<<"traversing in inorder "<<endl;
	b.inorder();
	b.isbst();
	b.isperfect();
	b.iscomplete();
	b.isfull();
	b.isbalance();
	b.is_left_skewed();
	 b.is_right_skewed();
	//cout<<" depth is"<<b.find_height;
	
}
