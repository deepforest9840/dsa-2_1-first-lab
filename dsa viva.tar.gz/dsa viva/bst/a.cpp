#include<iostream>
#include<queue>

using namespace std;
struct node{
	int data;
	struct node* left;
	struct node* right;
	
};
struct node* getnew(int data){
	struct node* root=(struct node*)malloc(sizeof(struct node));
	root->data=data;
	root->left=root->right=NULL;
	return root;
	
}
struct node* insert(struct node* root,int data){
	if(root==NULL){
		root=getnew(data);
	}
	else if(data<=root->data){
		root->left=insert(root->left,data);
		
	}
	else {
		root->right=insert(root->right,data);
	}
	return root;
	
}
bool search(node* root,int data){
	if(root==NULL) return false;
	else if(root->data==data) return true;
	else if(data<=root->data) return search(root->left,data);
	 return search(root->right,data);
}
int find_min(struct node* root){
	if(root==NULL) return -1;
	else if(root->left==NULL) {return root->data;}
	return find_min(root->left);
}
int find_max(struct node* root){
	if(root==NULL) return -1;
	else if(root->right==NULL){ return root->data;}
	return find_max(root->right);
}
int find_height(struct node* root){
	if(root==NULL) return -1;
	return max(find_height(root->left),find_height(root->right))+1;
}
void level_order(struct node* root){
	if(root==NULL) return ;
	queue<struct node*>q;
	q.push(root);
	while(!q.empty()){
		struct node* current=q.front();
		cout<<current->data<<" ";
		if(current->left!=NULL) q.push(current->left);
		if(current->right!=NULL)q.push(current->right);
		q.pop();
	}
}




int main(){
	struct node* root=NULL;
	root=insert(root,15);
	root=insert(root,10);
	root=insert(root,20);
	root=insert(root,25);
	root=insert(root,8);
	root=insert(root,12);
	
	
	/*int n;
	cin>>n;
	if(search(root,n)) cout<<"found";
	else cout<<"none";
	
	cout<<find_min(root)<<"   "<<find_max(root)<<"height"<<find_height(root);
	*/
	level_order(root);
	
	
	
	
}












