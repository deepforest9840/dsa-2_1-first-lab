#include<iostream>
using namespace std;
struct node{
	char a;
	int freq;
};
struct h{

		struct node* ar;
	h(int n){
	ar=new  node[10];
	}
	
	
	void show(){
		ar[0].a='a',ar[0].freq=5;
	ar[1].a='b',ar[1].freq=6;
	ar[2].a='c',ar[2].freq=3;
	ar[3].a='d',ar[3].freq=2;
	ar[4].a='e',ar[4].freq=1;
	for(int i=0;i<5;i++){
			for(int j=i+1;j<5;j++){
				if(ar[j].freq<ar[i].freq){
					struct node t=ar[j];
					ar[j]=ar[i];
					ar[i]=t;
				}
			}
	}
	
	for(int i=0;i<5;i++){
		cout<<ar[i].a<<" "<<ar[i].freq<<endl;
	}
	
	}
	
	
	
	
};
int main(){
	struct h h(10);
	h.show();
	
}
