#include<iostream>
#include<climits>
using namespace std;
struct minHeap{

	int *heap_ar;
	int heap_size;
	int capacity;
	minHeap(int cap){
		heap_size=0;
		capacity=cap;
		heap_ar=new int[cap];
	}
	
	int parent(int i){
		return (i-1)/2;
	}
	int left(int i){
		return (2*i+1);
	}
	int right(int i){
		return 2*i+2;
	}
	void min_heapify(int i){
		//cout<<"size is "<<heap_size<<endl;
		while(1){
			int l=left(i);
			int r=right(i);
			int smallest=i;
			if(l>=heap_size||r>=heap_size){
				break;
			}
			if(heap_ar[l]<heap_ar[smallest]){
				smallest=l;
			}
			if(heap_ar[r]<heap_ar[smallest]){
				smallest=r;
			}
			if(smallest!=i){
				int temp=heap_ar[smallest];
				heap_ar[smallest]=heap_ar[i];
				heap_ar[i]=temp;
				i=smallest;
			}
			else break;
		}
	
		
	}
	void insert(int value){
			if (heap_size == capacity)
		{
			cout << "\nOverflow: Could not insertKey\n";
			return;
		}
		heap_ar[heap_size]=value;
		int curr=heap_size;
		while(curr>0 		&&heap_ar[parent(curr)]>heap_ar[curr]){
			int temp=heap_ar[parent(curr)];
			heap_ar[parent(curr)]=heap_ar[curr];
			heap_ar[curr]=temp;
			curr=parent(curr);
		}
		heap_size++;
	
	}
	
	void pop(int i){//i ==index
		
		
	}
	int  extractMin(){
	//cout<<"size is "<<heap_size<<endl;
		if (heap_size <= 0)
		return INT_MAX;
		if (heap_size == 1)
		{
			heap_size--;
			return heap_ar[0];
		}
	
		int root=heap_ar[0];
		heap_ar[0]=heap_ar[heap_size-1];
		heap_size--;
		
		min_heapify(0);
		
		return root;
	
	
	}
	
	
	
	
	
	
	
	
	
	

	void show(){
	
	for(int i=0;i<heap_size;i++){
		cout<<heap_ar[i]<<" ";
		}
		cout<<endl;
	}
	int size(){
		return heap_size;
	}


};
int main()
{
	minHeap h(11);
	h.insert(3);
	h.insert(2);

	h.insert(15);
	h.insert(5);
	h.insert(4);
	h.insert(45);
	
	int a[11];
	//cout<<h.size()<<endl;
	h.show();
	int d=h.size();
	for(int i=0;i<d;i++){
		a[i]=h.extractMin();
	}
	for(int i=0;i<d;i++){
		cout<<a[i]<<" ";
	}
	//cout<<h.extractMin()<<endl;
	//h.show();
	//cout << h.extractMin() << " ";
	//cout << h.getMin() << " ";
	//h.decreaseKey(2, 1);
	//cout << h.getMin();
	return 0;
}


