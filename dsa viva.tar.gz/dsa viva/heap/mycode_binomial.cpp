#include<iostream>
#include<stdlib.h>
using namespace std;
struct node{
	int value;
	int degree;
	struct node*child;
	struct node*sibling;

	
};

struct node* createNode(int value){
	struct node* newNode=(struct node*) malloc(sizeof(struct node));
	newNode->value=value;
	newNode->degree=0;
	newNode->child=newNode->sibling=NULL;
	return newNode;
}
struct node* mergeHeaps(struct node* heap1,struct node* heap2){
	
	struct node* mergedHeap=NULL;
	if(heap1==NULL){
		return heap2;
	}
	else if(heap2==NULL){
		return heap1;
		
	}
	else {
	
		if(heap1->degree<=heap2->degree){
			mergedHeap=heap1;
			mergedHeap->sibling=mergeHeaps(heap1->sibling,heap2);
		}
		else {
			
			mergedHeap=heap2;
			mergedHeap->sibling=mergeHeaps(heap1,heap2->sibling);
			
		
			
		}
		return mergedHeap;
	
	}

}

struct node* insertNode(struct node* heap,int value){
	
	struct node* newNode=createNode(value);
	return mergeHeaps(heap,newNode);

}









int main(){

	struct node*heap=NULL;
	heap=insertNode(heap,10);
    heap = insertNode(heap, 20);
    heap = insertNode(heap, 30);
    heap = insertNode(heap, 40);
    heap = insertNode(heap, 50);
    printf("The binomial heap after insertion is: ");
    while (heap != NULL) {
        printf("%d ", heap->value);
        heap = heap->sibling;
    }
    return 0;

}
