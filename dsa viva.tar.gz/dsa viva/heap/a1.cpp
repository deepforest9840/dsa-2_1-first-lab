#include<iostream>
using namespace std;
struct node{
	int value;
	int degree;
	struct node* parent;
	struct node* child;
	struct node* sibling;
	

	
};
struct node* createNewNode(int value){
	struct node* newNode=(struct node*)malloc(sizeof(struct node));
	newNode->value=value;
	newNode->parent=NULL;
	newNode->child=NULL;
	newNode->sibling=NULL;
	newNode->degree=0;
	return newNode;


}
struct node* heap_merge(struct node* H1,struct node* H2){
	
	    struct node* H ;
    struct node* y;
    struct node* z;
    struct node* a;
    struct node* b;
    y = H1;
    z = H2;
    if (y != NULL) {
        if (z != NULL && y->degree <= z->degree)
            H = y;
        else if (z != NULL && y->degree > z->degree)
            /* need some modifications here;the first and the else conditions can be merged together!!!! */
            H = z;
        else
            H = y;
    } else
        H = z;
    while (y != NULL && z != NULL) {
        if (y->degree < z->degree) {
            y = y->sibling;
        } else if (y->degree == z->degree) {
            a = y->sibling;
            y->sibling = z;
            y = a;
        } else {
            b = z->sibling;
            z->sibling = y;
            z = b;
        }
    }
    return H;
}
void bin_Link(struct node* y, struct node* z) {
    y->parent = z;
    y->sibling = z->child;
    z->child = y;
    z->degree = z->degree + 1;
}
struct node* heap_union(struct node* H1,struct node* H2){

	struct node* H=heap_merge(H1,H2);
	if(H==NULL){
		return H;
	}
	struct node* prev=NULL;
	struct node* ptr=H;
	struct node* next=ptr->sibling;

	while(next!=NULL){
		
		//if((ptr->degree!=next->degree)|| ((next->sibling!=NULL)&& (next->sibling)->degree==ptr->degree))
		
		if((ptr->degree != next->degree) || ((next->sibling != NULL)
                && (next->sibling)->degree == ptr->degree)) {
			prev=ptr;
			ptr=next;
		}
		else{
		
			if(ptr->value<=next->value){
				ptr->sibling=next->sibling;
				bin_Link(next,ptr);
			}
			else{
			
				if(prev==NULL){
					H=next;
				}
				else {
					prev->sibling=next;
					
				}
				bin_Link(ptr,next);
					ptr=next;
			
			}
		
		
		}
		
		next=ptr->sibling;
		
	
	
	}

	return H;

}
struct node* insert(int value,struct node* heap){
	struct node* newNode=createNewNode(value);
	return heap_union(heap,newNode);
}
 int Display(struct node* H) {
    struct node* p;
    if (H == NULL) {
        printf("\nHEAP EMPTY");
        return 0;
    }
    printf("\nTHE ROOT NODES ARE:-\n");
    p = H;
    while (p != NULL) {
        printf("%d", p->value);
        if (p->sibling != NULL)
            printf("-->");
        p = p->sibling;
    }
    printf("\n");
    return 0;
}


int main(){

	struct node* heap=NULL;
	heap=insert(10,heap);
	heap=insert(20,heap);
	heap=insert(30,heap);
	heap=insert(40,heap);
	
	Display(heap);

}
