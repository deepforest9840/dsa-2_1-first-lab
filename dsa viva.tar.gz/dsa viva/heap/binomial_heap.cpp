#include <stdio.h>
#include <stdlib.h>

// Node structure for binomial heap
struct Node {
    int value;   // Node's value
    int degree;  // Degree of node (number of children)
    struct Node* child;   // Pointer to leftmost child node
    struct Node* sibling; // Pointer to sibling node
};

// Create a new node with given value
struct Node* createNode(int value) {
    struct Node* newNode = (struct Node*) malloc(sizeof(struct Node));
    newNode->value = value;
    newNode->degree = 0;
    newNode->child = NULL;
    newNode->sibling = NULL;
    return newNode;
}

// Merge two binomial trees of same degree
struct Node* mergeTrees(struct Node* tree1, struct Node* tree2) {
    if (tree1->value > tree2->value) {
        struct Node* temp = tree1;
        tree1 = tree2;
        tree2 = temp;
    }
    tree2->sibling = tree1->child;
    tree1->child = tree2;
    tree1->degree++;
   //k tree1->sibling=NULL;
    return tree1;
}

// Merge two binomial heaps and return the resulting heap
struct Node* mergeHeaps(struct Node* heap1, struct Node* heap2) {
    struct Node* mergedHeap = NULL;
    if (heap1 == NULL) {
        return heap2;
    } else if (heap2 == NULL) {
        return heap1;
    } else {
        if (heap1->degree <= heap2->degree) {
            mergedHeap = heap1;
            mergedHeap->sibling = mergeHeaps(heap1->sibling, heap2);
        } else {
            mergedHeap = heap2;
            mergedHeap->sibling = mergeHeaps(heap1, heap2->sibling);
        }
        return mergeTrees(mergedHeap,mergedHeap->sibling);
    }
}

// Insert a node with given value into the binomial heap
struct Node* insertNode(struct Node* heap, int value) {
    struct Node* newNode = createNode(value);
    return mergeHeaps(   heap, newNode);
}

int main() {
    struct Node* heap = NULL;
    heap = insertNode(heap, 10);
    heap = insertNode(heap, 20);
   
    printf("The binomial heap after insertion is: ");
    while (heap != NULL) {
        printf("%d ", heap->value);
        heap = heap->sibling;
    }
    return 0;
}

