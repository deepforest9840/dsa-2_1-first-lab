#include<iostream>
using namespace std;
int  amar(int n){
	if(n>5){
		cout<<n<<endl;
		amar(n-3);
		cout<<"recursion is occur "<< n<<endl;
	}
	
}

int main(){
	amar(10);
}
