#include<iostream>
using namespace std;
struct node{
	int parent;
	int rank;
};

struct dsu{
	int v;
	int cycle =0;
	struct node* ar=NULL;
	dsu(int v){
		ar=(struct node*)malloc(v*sizeof(struct node));
		for(int i=0;i<v;i++){
			ar[i].parent=-1;
			ar[i].rank=0;
		}
	}
	int find(int v){
		if(ar[v].parent==-1){
			return v;
		}
		return ar[v].parent=find(ar[v].parent);
	}
	
	void union_op(int from,int to){
	
	
		from=find(from);
		to=find(to);
		if(from==to && (from!=-1  && to!=-1)){
			cycle++;
		}
		if(ar[from].rank>ar[to].rank){
			ar[to].parent=from;
		}
		else if(ar[from].rank<ar[to].rank){
			ar[from].parent=to;
		}
		else{
			ar[from].parent=to;
			ar[to].rank++;
		}
	}
	
	void display(){
		for(int i=0;i<v;i++){
			cout<<ar[i].parent<<" ";
			
		}
	}
	
	void iscycle(){
		//for(int i=0;i<count;i++){
			
			
			//int f=find(ar_c[i][0]);
			
			//int t=find(ar_c[i][1]);
			//cout<<f<<" "<<t<<endl;
			///if (f==t && f!=-1&&t!=-1){
				if(cycle) cout<<endl<<"cycle detected us  "  << cycle<<endl;
				//return;
			//}
		//}
		else cout<<endl<<"no cycle detected no "<<endl;
		return ;
	}


};
int main(){
	struct dsu d(4);
	
			d.union_op(0,1);
		d.union_op(1,2);
		d.union_op(2,3);
		//d.union_op(0,2);
	d.iscycle();
	
	
	
	
	
	
	
	
}
