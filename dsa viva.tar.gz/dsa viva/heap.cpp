#include<iostream>
using namespace std;
#define SIZE 1001
int heap[SIZE];
int heapSize;
void push(int val){

	if(heapSize>=SIZE){
		cout<<"over_flow"<<endl;
		return;
	}
	heap[heapSize]=val;
	int curr=heapSize;
	while(curr>0&& heap[(curr-1)/2]<heap[curr]){
		
		int temp=heap[(curr-1)/2];
		heap[(curr-1)/2]=heap[curr];
		heap[curr]=temp;
		curr=(curr-1)/2;
		
		
	
		
	}
	
	heapSize+=1;






}

int pop(){
	
	int curr=0;
	int popped=heap[0];
	heap[0]=heap[heapSize-1];
	heapSize-=1;
	while(1){
	
			int largest=curr;
	int l=2*curr+1;
	int r=2*curr+2;
	if(l>=heapSize||r>=heapSize){break;}
	if(heap[l]>heap[largest]) {largest=l;}
	if(heap[r]>heap[largest]){
		largest=r;
	}
	if(largest!=curr){
	
		int temp=heap[curr];
		heap[curr]=heap[largest];
		heap[largest]=temp;
		curr=largest;
	
	
	}
	else break;
	
	
	
	
	
	}
	

	

	return popped;














}

void show(){
	
	for(int i=0;i<heapSize;i++){
		cout<<heap[i]<<" ";
	}




}


	void preorder(int index=0){
		if(heap[index]!=0){
			cout<<endl<<"index is "<<heap[index]<<endl;//" and name is: "<<s[index]<<endl;
			
			preorder(index*2+1);
			preorder(index*2+2);
		}
	}
 void init(){
 	heapSize=0;
 }


int main(){

	init();
	push(1);
	push(2);
	push(3);
	push(6);
	push(5);
	push(11);
	push(6);
	push(17);
	//cout<<pop()<<endl;
	//preorder();




}
























