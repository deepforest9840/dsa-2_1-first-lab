#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
}*top=NULL;
void push(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
}
void pop(){
	top=top->link;
}
void print(){
	struct node* temp=top;
	while(temp!=NULL){
		printf("%c ",temp->data);
		temp=temp->link;
	}
}
int isEmpty(){
	if(top==NULL) return 1;
	else return 0;
}
int peek(){
	return top->data;
}
void check(char s[]){
	int i=0;
	char a[10];
	while(s[i]){
		if(s[i]=='('||s[i]=='{'||s[i]=='['){push(s[i]);}
		else if(s[i]==')'||s[i]=='}'||s[i]==']'){
				if(top==NULL) {
					printf("unbalaned   " );
					return ;
				}
				else{
					if((s[i]==')'&&peek()=='(')||(s[i]==']'&&peek()=='[')||(s[i]=='}'&&peek()=='{')) {
					
					
					     pop();
					
					
					
					}
					else {
						printf("unbalanced"); return ;
					}
				}
		}
		i++;
	}
	if(top==NULL) printf("balanced");
	else printf("unbalanced");
	
	
}
int main(){
	char s[20];
	scanf("%s",s);
	check(s);
}
