#include<iostream>
using namespace std;
struct node{
	char data;
	struct node* link;
} *top=NULL;




void push(char data){
	
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
}
void pop(){


	 
    top=top->link;
    

	
}
void print(){
	struct node* temp=top;
	while(temp!=NULL){
		printf("%c ",temp->data);
		temp=temp->link;
	}
	printf("\n");
	
}

int isEmpty(){
	if(top==NULL) {return 1;}
	else {return 0;}
}

char peek(){
	 {
	char c=top->data; 
	return c;}
}
/*

*/
int main(){
	
	
	
	for(int i=0;i<25;i++){
	
	char a;
	scanf("%c ",&a);
	
	 if(a=='(') {push(a);}
	 
	if(c==')'){printf("unbalanced");}
	}
	 if(a==')') pop();
	
	
}
