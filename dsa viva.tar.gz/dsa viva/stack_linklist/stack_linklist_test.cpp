#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
};

struct stack{
	struct node*top=NULL;
void push(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
}
void pop(){
	top=top->link;
}
int peek(){
	return top->data;
}

int isEmpty(){
	if(top==NULL) return 1;
	return 0;
}
void print(){
	if(isEmpty()) {
		cout<<"stack is empty"<<endl;
		return;
	}
	struct node* p=top;
	while(p!=NULL){
		cout<<p->data<<endl;
		p=p->link;
	}
	cout<<endl;
}
};
int main(){
	struct stack q;
	q.push(8);
	q.push(7);
	q.pop();
	cout<<q.peek()<<endl;
	q.print();
	
	
}









