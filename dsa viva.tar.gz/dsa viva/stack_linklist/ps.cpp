#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
};

void push(int data,struct node** top){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=*top;
	*top=temp;
}
void print(struct node* top){
	struct node* temp=top;
	while(temp!=NULL){
		printf("%d ",temp->data);
		temp=temp->link;
	}
	printf("\n");
}

int pop(struct node** top){
		int val=(*top)->data;
		(*top)=(*top)->link;
		return val;
}
void add(struct node* top){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=3;
	while(top->link!=NULL){
		top=top->link;
	}
	top->link=temp;
}

int main(){
	struct node* top=NULL;
	push(7,&top);
	push(6,&top);
	push(5,&top);
	
	print(top);
	int d=pop(&top);
	printf(" last %d\n",d);

	print(top);
}
