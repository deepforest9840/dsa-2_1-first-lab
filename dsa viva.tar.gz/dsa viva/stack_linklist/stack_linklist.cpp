#include<iostream>
using namespace std;
struct node{
	char data;
	struct node* link;
}*top=NULL;



void push(int data){
	
	struct node *temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->link=top;
	top=temp;
}
void pop(){

	 
    top=top->link;
    

	
}
int isEmpty(){
	if(top==NULL) {return 1;}
	else {return 0;}
}
void print(){

	if(isEmpty()){	
			printf("stack underflow\n");
			exit(1);
	}
	struct node* temp=top;
	while(temp!=NULL){
		printf("%d ",temp->data);
		temp=temp->link;
	}
	printf("\n");
	
}



void peek(){
	if(top==NULL){ printf("stack underflow\n");}
	else{
		printf("%d\n",top->data);
	}
}
/*

*/
int main(){

	
	push(8);
	push(7);
	
	
	print();
	push(1);
	push(1);
	
}
