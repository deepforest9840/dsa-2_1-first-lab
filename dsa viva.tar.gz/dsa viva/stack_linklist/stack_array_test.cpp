#include<iostream>
using namespace std;
#define max 10
struct stack{
	int top=-1;
	int* ar;
	stack(){
		ar=new int[10];
		cout<<sizeof(int)<<endl;
	}
	void push(int data){
		if(top==max-1){
			cout<<"stack is overflow"<<endl;
			return;
		}
		top++;
		ar[top]=data;
	}
	void pop(){
		if(top==-1){
		cout<<"stack is underflow"<<endl;
		return;
		}
		top--;
	}
	int peek(){
		return ar[top];
	}
	bool isFull(){
		if(top==max-1) return true;
		else return false;
	}
	void print(){
		for(int i=top;i>=0;i--){
			cout<<ar[i]<<endl;
		}
	}
};
int main(){
	struct stack q;
	q.push(4);
	q.push(5);
	q.push(7);
	q.push(6);
	//q.pop();
	
	q.print();
	cout<<q.peek();
}

