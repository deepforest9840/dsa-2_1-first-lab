while(top!=NULL){
		printf("%c ",top->data);
		top=top->link;
	}
