#include<iostream>
using namespace std;

struct dsu{
	int v;
	int e;
	int* ar;
	
	int count=0;
	int cycle=0;
	
	dsu(int v){
		this->v=v;
		ar=new int[v];
		//ar_c=new int *[v];
		for(int i=0;i<v;i++){
			ar[i]=-1;
			//ar_c[i]=new int[2];
		}
		//display();
	}
	int find(int v){
		if(ar[v]==-1){
			return v;
		}
		if(ar[v]==v){
			return v;
		}
		return find(ar[v]);
	}
	
	void union_op(int from,int to){
	
		//ar_c[count][0]=from;
		//ar_c[count][1]=to;
		//cout<<ar_c[count][0]<<" "<<ar_c[count][1]<<endl;
		count++;
		from=find(from);
		
		to=find(to);
		
		//cout<<from<<" "<<to<<endl;
		if(from==to && (from!=-1  && to!=-1)){
			cycle++;
		}
		ar[from]=to;
		
		
	}
	void display(){
		for(int i=0;i<v;i++){
			cout<<ar[i]<<" ";
			
		}
	}
	void iscycle(){
		//for(int i=0;i<count;i++){
			
			
			//int f=find(ar_c[i][0]);
			
			//int t=find(ar_c[i][1]);
			//cout<<f<<" "<<t<<endl;
			///if (f==t && f!=-1&&t!=-1){
				if(cycle) cout<<endl<<"cycle detected us  "  << cycle<<endl;
				//return;
			//}
		//}
		else cout<<endl<<"no cycle detected no "<<endl;
		return ;
	}
	
	

};
int main(){
	int no_vertices=4;
	cout<<"enter no of vertices "<<no_vertices;
	//cin>>no_vertices;
	int v=no_vertices;
	struct dsu d(v);
	int e;//no of edges
	//cin>>e;
	//for(int i=0;i<=v;i++){
		d.union_op(0,1);
		d.union_op(1,2);
		d.union_op(2,3);
		d.union_op(0,3);
		
		//d.display();
		d.iscycle();
		
		
	//}
	
	
}























