#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node *front,*back;
	//struct node* back;
	queue(){
		front=back=NULL;
	}
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=back=temp;
			return ;
		}
		back->link=temp;
		back=temp;
		
	}
	void pop(){
		if(front==NULL){
		cout<<"stack is empty";
		return;
		}
		if(front==back){
			front=back=NULL;
			return;
		}
		front=front->link;
		
		
	}
	int peek(){
		return front->data;
	}
	void print(){
		struct node* p=front;
		while(p->link!=NULL){
			cout<<p->data<<endl;
			p=p->link;
		}
	}
	
		
};

int main(){
	struct queue q;
	q.push(3);
	q.push(31);
	q.push(32);
	q.push(33);
	q.push(34);
	q.push(35);
	q.push(36);
	q.push(37);
	q.print();
	
	
	
	
	
	
	
}




















