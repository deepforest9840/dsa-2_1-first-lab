#include<iostream>
#include<cstring>
using namespace std;
struct node{
	int dis;
	int pet;
	int no;
	
	struct node* link;
};
struct qq{
	
	struct node* front=NULL;
	struct node* rear=NULL;
	int size=0;
	int no=0;
	void push(int dis,int pet){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	size++;
	temp->dis=dis;
	temp->pet=pet;
	temp->no=no;
	no++;
	if(front==NULL){
		front=rear=temp;
		return;
	}
	struct node* head=front;
	while(head->link!=NULL)
		{
			head=head->link;
		}
	head->link=temp;
		
	}
	void output(){
		int bal=0;
		while(rear!=NULL){
			bal=bal+(rear->pet-rear->dis);
			if(bal>=0){
				rear=rear->link;
			}
			else if(bal<0){
				if(rear->link==NULL){cout<<"cannot solve tour problem ";return;}
				rear=front=rear->link;
			}
		}
		cout<<front->no;
		
	}
	void show(){
		struct node* p=front;
		for(int i=0;i<size;i++){
			cout<<" no is "<<i<<" dis is "<<p->dis<<"  pet is "<<p->pet<<endl;
			p=p->link;
		}
	}
};
	

int main(){

struct qq q;
q.push(5,6);
 q.push(6,7);
 q.push(7,4);
 q.push(8,10);
 q.push(6,6);
 q.push(14,5);
 q.output();
// q.show();




}
