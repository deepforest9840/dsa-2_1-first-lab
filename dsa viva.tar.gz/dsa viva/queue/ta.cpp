#include<iostream>
#include<cstring>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node* front;
	struct node* back;
	queue(){
		front=NULL;
		back=NULL;
	}
	int count=0;
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=temp;
			back=temp;
			count++;
		}
		else{
		back->link=temp;
		back=temp;
		//back->link=front;
		count++;
		}
		
	}
	void pop(){
		if(front==NULL||front>back){
		cout<<"queue is underfloq"<<endl;
		return ;
		}
		if(front==back){
			front=back=NULL;
			count--;
			return ;
			
		}
		front=front->link;
		//back->link=front;
		count--;
	}
	int peek(){
		return front->data;
	}
	bool isempty(){
		if(front==NULL||front>back) return true;
		else return false;
	}
	void show(){
		struct node* temp=front;
		for(int i=1;i<=count;i++){
			printf("%d ",temp->data);
			temp=temp->link;
		}
	}
	
	int size(){
		return count;
	}
	void output(int size1,int target,int sf){
	
			int count=size1;
			int c[size1];
			int size=0;
		for(int i=0;i<count-1-1;i++){
			struct node* temp1=front;
			int sum=sf;
		int	supercount=0;
			
			while(sum<target){
			
			sum+=temp1->data;
			temp1=temp1->link;
			supercount++;
			}
			c[size]=supercount;
			size++;	
			supercount=0;
			front=front->link;
		
			
			
		}
		
			for(int i=0;i<size-1;i++){
			for(int j=i+1;j<size;j++){
				if(c[j]<c[i]){
					int t=c[j];
					c[j]=c[i];
					c[i]=t;
					
				}
			}
		}
		cout<<c[0]<<" ";
		
		
		
		}
	
	
};


	

int main(){

//output(3
queue q;
q.push(60);
q.push(30);
q.push(30);
q.push(40);


//q.show();
//size target sf 
q.output(q.size(),100,10);





}
