#include<iostream>
using namespace std;
struct node{
	int data;
	int pri;
	struct node* next;
};
struct pq{
	
	struct node* head;
	struct node* tail;
	pq(){
		head=tail=NULL;
	}
	void enq(int data,int pri){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		temp->pri=pri;
		if(head==NULL){
			head=tail=temp;
			return;
		}
		tail->next=temp;
		tail=temp;
	}
	void deq(){
		if(head==NULL){
			cout<<"pq is empty";
			return;
		}
		
		struct node* temp=head;
		struct node* maxp=head;
		while(temp!=NULL){
			if(maxp->pri<temp->pri){
				maxp=temp;
			}
			temp=temp->next;
		}
		temp=head;
		cout<<"deleting  the value of highest priority "<<maxp->data<<" and its pri is "<<maxp->pri<<endl;
		
		if(head==tail){
			head=tail=NULL;
			return ;
		}
		while(temp->next!=maxp){
			temp=temp->next;
		}
		if(maxp==tail){
			tail=temp;
		}
		temp->next=maxp->next;
	}
	void print(){
		struct node* temp=head;
		cout<<"printing the value"<<endl;
		while(temp!=NULL){
			cout<<"pri is : "<< temp->pri<<" value is : "<< temp->data<<endl;
			temp=temp->next;
		}
	}
			
};
int main(){
		pq q;
	q.enq(10,5);
	
	q.print();
	q.deq();
	q.print();
	q.enq(3,6);
	q.print();
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

