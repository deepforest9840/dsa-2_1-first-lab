#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node* front;
	struct node* back;
	queue(){
		front=NULL;
		back=NULL;
	}
	int count=0;
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=temp;
			back=temp;
			count++;
		}
		else{
		back->link=temp;
		back=temp;
		back->link=front;
		count++;
		}
		
	}
	void pop(){
		if(front==NULL){
		cout<<"queue is underfloq"<<endl;
		return ;
		}
		if(front==back){
			front=back=NULL;
			count--;
		}
		front=front->link;
		back->link=front;
		count--;
	}
	int peek(){
		return front->data;
	}
	
	void show(){
		struct node* temp=front;
		for(int i=1;i<=count;i++){
			printf("%d ",temp->data);
			temp=temp->link;
		}
	}
	void j(){
	
	
	struct node* ptr=back;
	for(int c=5   ;c>1;c--){
		for(int i=0;i<3-1;i++){
			ptr=ptr->link;
		}
		printf("  %d is deleted",ptr->link->data);
		ptr->link=ptr->link->link;
	}
	printf(" \nthe winner is %d",ptr->data);
	}
};
int main(){



	queue q;
	
 	
	for(int i=1;i<=5;i++){
		q.push(i);
	}
	q.j();













}
