#include<iostream>
#include<cstring>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node* front;
	struct node* back;
	queue(){
		front=NULL;
		back=NULL;
	}
	int count=0;
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=temp;
			back=temp;
			count++;
		}
		else{
		back->link=temp;
		back=temp;
		//back->link=front;
		count++;
		}
		
	}
	void pop(){
		if(front==NULL||front>back){
		cout<<"queue is underfloq"<<endl;
		return ;
		}
		if(front==back){
			front=back=NULL;
			count--;
			return ;
			
		}
		front=front->link;
		//back->link=front;
		count--;
	}
	int peek(){
		return front->data;
	}
	bool isempty(){
		if(front==NULL||front>back) return true;
		else return false;
	}
	void show(){
		struct node* temp=front;
		for(int i=1;i<=count;i++){
			printf("%d ",temp->data);
			temp=temp->link;
		}
	}
	void j(){// josheopus problem solution
	
	
	struct node* ptr=back;
	for(int c=5   ;c>1;c--){
		for(int i=0;i<3-1;++i){
			ptr=ptr->link;
		}
		printf("  %d is deleted",ptr->link->data);
		ptr->link=ptr->link->link;
	}
	printf(" \nthe winner is %d",ptr->data);
	}
	
	
	
	
	 int delete_back(){
		struct node* temp=front;
		while(temp->link!=back){
			temp=temp->link;
			if(temp->link==NULL) break;
		}
		int a=back->data;
		back=temp;
		return a;
	}
	int delete_front(){
		struct node* temp=front;
		int val=front->data;
		front=front->link;
		return val;
	}
	
	
	
	
	
	
	
	
	
	
	
	
};
void ispalindrome(char* s){
		int l=strlen(s);
		queue q;
		for(int i=0;i<l;i++){
			q.push(s[i]);
		}
		q.show();
		printf("\n");
		
	if(l%2==0){
		for(int i=0;i<l/2;i++){
			if(q.delete_front()!=q.delete_back()){
				cout<<"not a palindrome";
				return;
			}
		}
		cout<<"palindrome";
	}
	else{
		for(int i=0;i<l/2-1;i++){
			if(q.delete_front()!=q.delete_back()){
				cout<<"not a palindrome";
				return;
			}
		}
		cout<<"palindrome";
	}
	
	
	
	}

struct stk{
	int n;
	queue q1;
	queue q2;
	void pushg(int data){
		q2.push(data);
		while(!q1.isempty()){
			q2.push(q1.peek());
			//cout<<q1.peek();
		q1.pop();
			
			//break;
		}
		queue temp;
		temp=q1;
		q1=q2;
		q2=temp;
	}
	void push(int data){
	
		while(!q1.isempty()){
		q2.push(q1.peek());
		q1.pop();
		}
		q1.push(data);
		while(!q2.isempty()){
			q1.push(q2.peek());
			q2.pop();
		}
	}
	void pop(){
		q1.pop();
	}
	int  peek(){
		return q1.peek();
	}
	void show(){
		q1.show();
	}
	bool isempty(){
		return q1.isempty();
	}
	
};
struct que{
	stk s1,s2;
	void push(int data){
		while(!s1.isempty()){
			s2.push(s1.peek());
			s1.pop();
		}
		s1.push(data);
		while(!s2.isempty()){
			s1.push(s2.peek());
			s2.pop();
		}
	}
	void pop(){
		s1.pop();
	}
	int peek(){
		return s1.peek();
	}
	void show(){
		s1.show();
	}
};

int main(){

//char s[10];
//scanf("%s",s);
//ispalindrome(s);
que s;
s.push(1);
 s.push(2);
 s.push(3);
 s.push(4);
 s.push(5);
 s.show();
 s.pop();
 s.show();



}
