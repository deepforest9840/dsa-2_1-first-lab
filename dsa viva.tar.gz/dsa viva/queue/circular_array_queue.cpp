  #include<iostream>
using namespace std;

#define n 5
struct queue{
	int front;
	int back;
	int* arr;
	
	 queue(){
		arr=new int[n];
		front=-1;
		back=-1;
	}
	
	void push(int data){
		if((back+1)%n==front){
			cout<<"--------queue is full"<<endl;
			return;
		}
		back=(back+1)%n;
		arr[back]=data;
		if(front==-1){
		front++;
		}
		
	}
	void pop(){
		if(front==-1){
			cout<<"queue is empty"<<endl;
			return;
		}
		if(front==back){front=back=-1;}
		else front=(front+1)%n;
	}
	int peek(){
		if(front==-1){
			cout<<"queue is empty"<<endl;
			return -1;
		}
		return arr[front];
	}
	bool empty()
	{
		if(front==-1){
			//cout<<"queue is empty"<<endl;
			return true;
		}
		return false;	
	}
	
	
	
	void show(){
	
		if(front<=back){
		int f=front;
		for(int i=front;i<=back;i++){
			printf("%d ",arr[i]);
			}
      	}
	    else {
	    	int i=front;
	    	while(i<n){
	    		printf("%d ",arr[i]);
	    		i++;
	    	}
	    	i=0;
	    	while(i<=back){
	    		printf("%d ",arr[i]);
	    		i++;
	    	}
	    }
	
	
	
	}
};
int main(){
	 queue q;
	q.push(1);
	q.push(2);
	q.push(3);
	q.push(4);
	
	q.push(6);

	q.push(5);	q.pop();
	q.show();
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
