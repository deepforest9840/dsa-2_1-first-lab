#include<iostream>
using namespace std;
#define max 20
struct queue{
	int front;
	int back;
	int ar[max];
	queue(){
		front=back=-1;
	}
	void push(int data){
		if(back==max-1){
			cout<<"full";
			return;
		}
		back++;
		ar[back]=data;
		if(front==-1){
			front++;
		}
	}
	void pop(){
		if(front==-1){
			cout<<"queue is empty";
			return ;
		}
		if(front==back){
			front=back=-1;
			return;
		}
		front++;
		
	}
	int peek(){
	return ar[front];
	}
	void print(){
		
		for(int i=front;i<=back;i++){
			cout<<ar[i]<<endl;
		}
	
	}
};

int main(){
	 queue q;
	q.push(1);
	q.push(2);
	q.push(3);
	q.push(4);
	q.pop();
	q.push(66);
	q.print();
	
}














