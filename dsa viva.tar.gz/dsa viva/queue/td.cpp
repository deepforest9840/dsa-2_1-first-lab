#include<iostream>
#include<cstring>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node* front;
	struct node* back;
	queue(){
		front=NULL;
		back=NULL;
	}
	int count=0;
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=temp;
			back=temp;
			count++;
		}
		else{
		back->link=temp;
		back=temp;
		//back->link=front;
		count++;
		}
		
	}
	void pop(){
		if(front==NULL||front>back){
		cout<<"queue is underfloq"<<endl;
		return ;
		}
		if(front==back){
			front=back=NULL;
			count--;
			return ;
			
		}
		front=front->link;
		//back->link=front;
		count--;
	}
	int peek(){
		return front->data;
	}
	bool isempty(){
		if(front==NULL||front>back) return true;
		else return false;
	}
	void show(){
		struct node* temp=front;
		for(int i=1;i<=count;i++){
			printf("%d ",temp->data);
			temp=temp->link;
		}
	}
	
	int size(){
		return count;
	}
	void output(int size,int k){
	
			int count=size-size%k;
		for(int i=0;i<count;i++){
			struct node* temp1=front;
			
			int arr[k];
			for(int j=0;j<k;j++){
				arr[j]=temp1->data;
				temp1=temp1->link;
			}
			
				
				for(int ii=0;ii<k-1;ii++){
			for(int ji=ii+1;ji<k;ji++){
				if(arr[ji]>=arr[ii]){
					int t=arr[ji];
					arr[ji]=arr[ii];
					arr[ii]=t;
					
				}
			}
		}
		cout<<arr[0]<<" ";
		
		front=front->link;
		
		
		}
	}
	
};


	

int main(){

//output(3
queue q;
q.push(1);
q.push(3);
q.push(-1);
q.push(-3);
q.push(5);
q.push(3);
q.push(6);
q.push(7);
//q.show();
q.output(8,3);





}
