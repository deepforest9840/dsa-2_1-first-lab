#include<iostream>
using namespace std;
class linklist{
	public:
	int data;
	int pri;
	linklist* next;
	linklist(int data,int pri){
		this->data=data;
		this->pri=pri;
		this->next=NULL;
	}
	
	
};
class pq{
	linklist* head;
	linklist* tail;
	public:
	pq(){
		head=tail=NULL;
	}
	void enq(int data,int pri){
		linklist* newnode=new linklist(data,pri);
		if(head==NULL) {
			head=tail=newnode;
			return;
		}
		tail->next=newnode;
		tail=newnode;
		
	}
	void deq(){
		if(head==NULL){
			cout<<"pq  is empty";
			return ;
			
		}
		linklist* temp=head;
		linklist* maxp=head;
		while(temp!=NULL){
			if(maxp->pri<temp->pri){
				maxp=temp;
			}
			temp=temp->next;
		}
		
		 
		temp=head;
		
		cout<<"deleting highest value:  "<<maxp->data <<"  with priority:  "<<maxp->pri<<endl;
		if(head->next==NULL){
			head=NULL;
			return ;
		}
		while(temp->next!=maxp){
			temp=temp->next;
		}
		if(maxp==tail){
		tail=temp;
		}
		temp->next=maxp->next;
		
		
		
	}
	
	void print(){
		linklist* temp=head;
		cout<<"printing the value"<<endl;
		while(temp!=NULL){
			cout<<"pri is: "<<temp->pri<<"  data  is: "<<temp->data<<endl;
			temp=temp->next;
			
		}
	}
	
	
	
};

int main(){
	pq q;
	q.enq(10,5);
	q.enq(20,8);
	q.enq(30,7);
	q.enq(40,9);
	q.enq(50,4);
	q.enq(60,1);
	q.enq(70,26);
	
	q.print();
	q.deq();
	q.print();
	q.enq(3,6);
	q.print();
	
}






























