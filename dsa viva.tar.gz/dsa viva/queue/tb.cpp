#include<iostream>
#include<cstring>
using namespace std;
struct node{
	int data;
	struct node* link;
};
struct queue{
	struct node* front;
	struct node* back;
	queue(){
		front=NULL;
		back=NULL;
	}
	int count=0;
	void push(int data){
		struct node* temp=(struct node*)malloc(sizeof(struct node));
		temp->data=data;
		if(front==NULL){
			front=temp;
			back=temp;
			count++;
		}
		else{
		back->link=temp;
		back=temp;
		//back->link=front;
		count++;
		}
		
	}
	void pop(){
		if(front==NULL||front>back){
		cout<<"queue is underfloq"<<endl;
		return ;
		}
		if(front==back){
			front=back=NULL;
			count--;
			return ;
			
		}
		front=front->link;
		//back->link=front;
		count--;
	}
	int peek(){
		return front->data;
	}
	bool isempty(){
		if(front==NULL||front>back) return true;
		else return false;
	}
	void show(){
		struct node* temp=front;
		for(int i=1;i<=count;i++){
			printf("%d ",temp->data);
			temp=temp->link;
		}
	}
	
	int size(){
		return count;
	}
	
	
};

void output(int ac){
	
		int count=0;
		int x=8;
		queue qq[65];
		int a[]={1,3,4,6,2,5};
		int n=(sizeof(a))/(sizeof(a[0]));
		for(int i=0;i<n;i++){
			int j=i;int s=0;
			while(1){
			s=s+a[j];
			if(s>x){break;}
			if(a[j]==0){break;}	
				qq[i].push(a[j]);
				j++;	
			}
		}
		for(int i=0;i<n;i++){
			qq[i].show();
			cout<<endl;
		}
		int arr[n];
		for(int i=0;i<n;i++){
			arr[i]=qq[i].size();
		}
		
		//sorting portion
		for(int i=0;i<n-1;i++){
			for(int j=i+1;j<n;j++){
				if(arr[j]>=arr[i]){
					int t=arr[j];
					arr[j]=arr[i];
					arr[i]=t;
				}
			}
		}
		cout<<"output is "<<endl;
		for(int i=0;i<n;i++){
			if(qq[i].size()==arr[0]) {
				qq[i].show();
				break;
			}
		}
}
	

int main(){

output(3);





}
