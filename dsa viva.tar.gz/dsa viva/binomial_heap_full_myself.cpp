#include<iostream>
using namespace std;
struct node{
	int value;
	int degree;
	struct node* parent;
	struct node* child;
	struct node* sibling;
	

	
};
	struct node* heap=NULL;
	struct node* Hr=NULL;
struct node* createNewNode(int value){
	struct node* newNode=(struct node*)malloc(sizeof(struct node));
	newNode->value=value;
	newNode->parent=NULL;
	newNode->child=NULL;
	newNode->sibling=NULL;
	newNode->degree=0;
	return newNode;


}
struct node* heap_merge(struct node* H1,struct node* H2){
	
	    struct node* H ;
    struct node* y;
    struct node* z;
    struct node* a;
    struct node* b;
    y = H1;
    z = H2;
    if (y != NULL) {
        if (z != NULL && y->degree <= z->degree)
            H = y;
        else if (z != NULL && y->degree > z->degree)
            /* need some modifications here;the first and the else conditions can be merged together!!!! */
            H = z;
        else
            H = y;
    } else
        H = z;
    while (y != NULL && z != NULL) {
        if (y->degree < z->degree) {
            y = y->sibling;
        } else if (y->degree == z->degree) {
            a = y->sibling;
            y->sibling = z;
            y = a;
        } else {
            b = z->sibling;
            z->sibling = y;
            z = b;
        }
    }
    return H;
}
void bin_Link(struct node* y, struct node* z) {
    y->parent = z;
    y->sibling = z->child;
    z->child = y;
    z->degree = z->degree + 1;
}
struct node* heap_union(struct node* H1,struct node* H2){

	struct node* H=heap_merge(H1,H2);
	if(H==NULL){
		return H;
	}
	struct node* prev=NULL;
	struct node* ptr=H;
	struct node* next=ptr->sibling;

	while(next!=NULL){
		
		//if((ptr->degree!=next->degree)|| ((next->sibling!=NULL)&& (next->sibling)->degree==ptr->degree))
		
		if((ptr->degree != next->degree) || ((next->sibling != NULL)
                && (next->sibling)->degree == ptr->degree)) {
			prev=ptr;
			ptr=next;
		}
		else{
		
			if(ptr->value<=next->value){
				ptr->sibling=next->sibling;
				bin_Link(next,ptr);
			}
			else{
			
				if(prev==NULL){
					H=next;
				}
				else {
					prev->sibling=next;
					
				}
				bin_Link(ptr,next);
					ptr=next;
			
			}
		
		
		}
		
		next=ptr->sibling;
		
	
	
	}

	return H;

}
struct node* insert(int value,struct node* heap){
	struct node* newNode=createNewNode(value);
	return heap_union(heap,newNode);
}
 int Display(struct node* H) {
    struct node* p;
    if (H == NULL) {
        printf("\nHEAP EMPTY");
        return 0;
    }
    printf("\nTHE ROOT NODES ARE:-\n");
    p = H;
    while (p != NULL) {
        printf("%d", p->value);
        if (p->sibling != NULL)
            printf("-->");
        p = p->sibling;
    }
    printf("\n");
    return 0;
}
void revert(struct node* y){
	if(y->sibling!=NULL){
		revert(y->sibling);
		y->sibling->sibling=y;
	}
	else{
		Hr=y;
	}
}
struct node* extract(struct node* H1){
	struct node* t=NULL;
	struct node* x=H1;
	struct node* p;
	Hr=NULL;
	if(x==NULL){
		cout<<"noting to extract"<<endl;
		return x;
	}
	int min=x->value;
	p=x;
	while(p->sibling!=NULL){
		if((p->sibling->value)<min){
			min=p->sibling->value;
			x=p->sibling;
			t=p;
		}
		p=p->sibling;
	}
	
	if(t==NULL&&x->sibling==NULL){
		H1=NULL;
	}
	else if(t==NULL){
		H1=x->sibling;
	}
	else if(t->sibling==NULL){
		t=NULL;//i think this cannot help me
	}
	else {t->sibling=x->sibling;}
	if(x->child!=NULL){
		revert(x->child);
		x->child->sibling=NULL;
	}
	heap=heap_union(H1,Hr);
	return x;

}
struct node* find_node(struct node* H,int k){
	struct node* x=H;
	struct node*p=NULL;
	if(x->value==k){
		p=x;
		return p;
	}
	if(x->child!=NULL && p==NULL){
		p=find_node(x->child,k);
	}
	if(x->sibling!=NULL && p==NULL){
		p=find_node(x->sibling,k);
	}
	return p;

}
void decrease(struct node* heap,int old_value,int new_value){

	struct node* p;
	struct node* y;
	struct node* z;
	p=find_node(heap,old_value);
	if(p==NULL){
		cout<<endl<<"invalid choice of key to be reduced"<<endl;
		return;
	}
	if(new_value>p->value){
		cout<<"\n oh!! the new value is greater than current value which is illogic for this function"<<endl;
		return ;
		
	}
	p->value=new_value;
	y=p;
	z=p->parent;
	while(z!=NULL && y->value < z->value){
		int t=y->value;
		y->value=z->value;
		z->value=t;
		y=z;
		z=z->parent;
	}
	cout<<"\n key is reduced successfully and display the heap is "<<endl;
	Display(heap);

}
void delete_node(struct node* H,int value){
	if(H==NULL){
		cout<<"\n Heap is Empty"<<endl;
		return ;
	}
	decrease(H,value,-1000);
	struct node* np=extract(H);
	if(np!=NULL){
	cout<<"\nsuccess deleting"<<endl;}
}
int main(){


	heap=insert(10,heap);
	heap=insert(20,heap);
	heap=insert(30,heap);
	heap=insert(40,heap);
	heap=insert(50,heap);
	//struct node* x=extract(heap);
	//cout<<"value of the extract key is"<<x->value<<" and its degree is "<<x->degree<<endl;
	
	Display(heap);
	delete_node(heap,10);
	Display(heap);
	//decrease(heap,40,5);
	//cout<<heap->child->value;
	
	
	

}
