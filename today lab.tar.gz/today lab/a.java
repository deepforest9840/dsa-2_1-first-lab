import java.util.Scanner;

class information{
    private String name;
    private String address;
    information(String a,String b){
        name=a;
        address=b;

    }
    information(){
        name="";
        address="";

    }

    public void display(){
        System.out.println("The world is beautiful.");
        System.out.println("The humans living in this world must also have beautiful hearts.");
        System.out.println("The humans living in this world must also have beautiful hearts.");
        System.out.println("The humans living in this world must also have beautiful hearts.");
        System.out.println(name);
        System.out.println(address);
    }


}
public class a{
    public static void main(String[] args) {
        information p1=new information();
        p1.display();


    }
}
