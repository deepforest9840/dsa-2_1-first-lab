class A{
   private int n;

   A(int a){
       n=a;

   }

}
class B{
  private   int n;
   private int m;
    B(int a){
        n=a;

    }
    B(){


    }



}
public  class j{
    public static void main(String[] args) {
        int n=4;
        int m=5;
        A a=new A(n);
        A c=new A(n);
        A b=new A(m);

        B a1=new B(n);
        B b1=new B(m);
        B c1=new B();


       // System.out.println(a1.n);
    }
}
