import java.util.Scanner;

class two_d{
    public int x;
    public int y;
    public int num;
    two_d(int x,int y){
        this.x=x;
        this.y=y;
        //num=x+y;

    }
    two_d(){
        x=4;
        y=5;

    }
    public void add(int a,int b){
        x=a;
        y=b;
        //return num=x+y;
        num=x+y;
        System.out.println(num);
    }
   public void radd(){
       System.out.println(x+y);
   }


}
public class d{
    public static void main(String[] args) {
        two_d p1=new two_d(3,6);//here this constructor set the two variable value


        System.out.print("first addition with constructore vlaue:  ");
        p1.add(p1.x,p1.y);//
        System.out.print("second addition with input value:  ");
       // p1.add(30,4);
        System.out.println("print from main  "+p1.num);
        //p1.add(p1.x,p1.y);

        System.out.println("first variable of the constructor is: "+p1.x+"     second value of the constructor is :  "+p1.y);

        System.out.print("third addition with the constructor value:  ");
        p1.radd();

        System.out.println("here we see that the value of constructor variable is changed.So,call by reference is fully working,,");
       // p1.add(5,5);
       // p1.add(p1.x,p1.y);
        //p1.add();


    }
}
