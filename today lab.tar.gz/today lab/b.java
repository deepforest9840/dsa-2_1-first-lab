import java.util.Scanner;

public class b{
    public static void main(String[] args) {
        Scanner a=new Scanner(System.in);
        int aa=a.nextInt();
        System.out.println(aa);
    }
}
