import java.util.Scanner;

class student{
    private String name;
    private int roll;
    student(String a){
            if(a=="old")
            {
            name="csedu";
            roll=27;


            }
            else{
                name="csedu";
            }
    }
    student(String name,int n){
        this.name=name;
        roll=n;
    }
    student(){
        name="faka";
        roll=4;

    }
    public void display(){
        System.out.println("name is "+name);
        System.out.println("roll is "+roll);
    }
}
public class b{
    public static void  another(String p){
        student s=new student(p);
        //s.display();

    }
    public static void main(String[] args) {
       String a,a1;
       a="old";
       a1="new";
       another(a1);
        student s=new student(a);
        s.display();
      //another(a).display();



    }

}
