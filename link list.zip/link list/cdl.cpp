#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* prev;
	struct node* next;
};
struct node* circularlinklist(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->next=temp;
	temp->prev=temp;
	temp->data=data;
	return temp;
}
int main(){
	struct node* tail;
	int data=55;
	tail=circularlinklist(data);
	printf("%d\n",tail->data);
}
