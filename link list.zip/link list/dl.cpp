#include<iostream>
using namespace std;
struct node{
	struct node* prev;
	
	int data;
	struct node* next;
};
struct node* add(struct node* head,int data){
	head->prev=NULL;
	head->next=NULL;
	head->data=data;
	return head;
}
struct node* addbeg(struct node* head,int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	if(head->data==0){
		head->data=data;
		return head;
	}
	head->prev=temp;
	temp->data=data;
	temp->next=head;
	//temp->prev=head;
	
	//head=temp;
	return temp;
}
struct node* addend(struct node* head,int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->prev=NULL;
	temp->next=NULL;
	struct node* ptr;
	ptr=head;
	while(ptr->next!=NULL){
		ptr=ptr->next;
	}
	
	temp->data=data;
	ptr->next=temp;
	
	temp->prev=ptr;
	return head;
}
struct node* addpos(struct node* head,int data,int position){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->prev=NULL;
	temp->next=NULL;
	struct node* ptr;
	ptr=head;
	for(int i=1;i<position-1;i++){
		ptr=ptr->next;
		
	}
	temp->next=ptr->next;
	temp->data=data;
	ptr->next=temp;
	
	
	temp->prev=ptr;
	return head;
}
struct node* del_first(struct node* head){
	struct node* temp=(struct node*)malloc(sizeof(struct node));;
	temp=head->next;
	//head=head->next;
	temp->prev=NULL;
	
	return temp;
	
}
struct node* del_last(struct node* head){
	struct node* temp=head;
		struct node* temp2=head;
	while(temp->next!=NULL){
		temp=temp->next;
	}
	temp2=temp->prev;
	temp2->next=NULL;
	return head;
	
}


int main(){
	struct node* head=(struct node*)malloc(sizeof(struct node));
	//struct node* ptr=(struct node*)malloc(sizeof(struct node));
//head=add(head,44);
	head=addbeg(head,24);
	//head=addbeg(head,25);
		
	//head=add(head,44);
//head=addend(head,55);
	//head=addend(head,355);
	//head=addend(head,525);
	//head=addend(head,5235);//head=addbeg(head,25);
	//head=addpos(head,67,3);
	//head=del_first(head);
	//head=del_last(head);//head=del_last(head);	  
	//head=del_first(head);
		//head=addbeg(head,24);
	while(head!=NULL){
	printf("%d\n",head->data);
	head=head->next;
	}
	
}
