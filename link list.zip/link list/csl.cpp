#include<iostream>
using namespace std;
struct node{
	int data;
	struct node* next;
};
struct node* addtoempty(int data){
	struct node* temp=(struct node*)malloc(sizeof(struct node));
	temp->data=data;
	temp->next=temp;
	return temp;
}
struct node* add_beg(struct node* tail,int data){
	struct node* newp=(struct node*)malloc(sizeof(struct node));
	newp->next=tail->next;
	newp->data=data;
	tail->next=newp;
	//tail=tail->next;
	return tail;
	
	
}
struct node* add_end(struct node* tail,int data){
	struct node* newp=(struct node*)malloc(sizeof(struct node));
	newp->next=tail->next;
	newp->data=data;
	tail->next=newp;
	tail=tail->next;
	return tail;
	
	
}
void print(struct node* tail){
	struct node* p=tail->next;
	do{
		printf("%d\n",p->data);
		p=p->next;
		
	}while(p!=tail->next);
}
struct node* del_end(struct node* tail){
	struct node* temp=tail->next;
	while(temp->next!=tail){
		temp=temp->next;
	}
	temp->next=tail->next;
	free(tail);
	tail=temp;
	return tail;
	
	
}
int main(){
	struct node* tail=(struct node*)malloc(sizeof(struct node));
	int data=43;
	tail=addtoempty(data);
	
	tail=add_beg(tail,55);
	//tail=add_end(tail,25);
		//tail=addtoempty(data);
	print(tail);
	//printf("after del\n");
	//tail=del_end(tail);
	//print(tail);
}
