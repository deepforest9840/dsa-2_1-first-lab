#include<iostream>
using namespace std;
struct node{
	int data;
	struct node *link;
};
void print(struct node *head,int data1){
struct node *temp=(struct node *)malloc(sizeof(struct node));
	temp->data=data1;
	
	while(head->link!=NULL){

		//printf("%d\n",head->data);
			head=head->link;
	}
	head->link=temp;//head=head->link;
	//printf("%d",head->data);
}
void print1(struct node *head){
	while(head!=NULL){
		printf("%d\n",head->data);
		head=head->link;
	}
}
int main(){
	struct node *head=(struct node *)malloc(sizeof(struct node));
	head->data=55;
	struct node *current=(struct node *)malloc(sizeof(struct node));
	current->data=65;
	head->link=current;
	current=(struct node *)malloc(sizeof(struct node));
	current->data =77;
	head->link->link=current;
	
	print(head,23);
	print1(head);
	
}
